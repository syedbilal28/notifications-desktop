import requests
import json
import time
import tkinter as tk
from tkinter import *
import webbrowser
# from win10toast import ToastNotifier
from win10toast import ToastNotifier
from pystray import MenuItem as item
import pystray
from PIL import Image
import threading
class Notification:
    def __init__(self,Type,link,title,description,icon):
        self.type=Type
        self.link=link
        self.title=title
        self.description=description
        self.icon=icon
    def __str__(self):
        return self.title
def tray():
    pass
def icon_action():
    image = Image.open("inprovo-favicon.ico")
    menu = (item('name', tray), item('name', tray))
    icon = pystray.Icon("name", image, "title", menu)
    icon.run()
    
def GetData():
    res=requests.get("https://app.inprovo.nl/api/v1/notifications")
    res=res.json()
    notifications=[]
    for i in res['notifications']:
        notifications.append(Notification(i['type'],i['url'],i['title'],i['description'],i['icon']))
    return notifications
def notify(title,text,url):
   noti.show_toast(title,text,duration=5, threaded=True,callback_on_click=action) 

def action():
    global url
    webbrowser.open_new(url)
    print("Done")    
 
noti = ToastNotifier()
while True:
    starttime=time.time()
    #Code would come here
    notifications=GetData()
    print(notifications)
    
    if len(notifications) >0:
        for notification in notifications:
            print(notification.title)
            if notification.type=="email":
                icon_thread = threading.Thread(target=icon_action,name="icon_thread",args=())
                # icon_action()
                
                # time.sleep(5)            
            else:
                # pass
                url=notification.link
                notify(notification.title,notification.description,notification.link)
                # x=threading.Thread(target=notify,args=(notification.title,notification.description,notification.link,))
                # threads.append(x)
                time.sleep(10)
    #Timer code
    time.sleep(5.0 - ((time.time() - starttime) % 5.0))

    # time.sleep(10)
    
# top = tk.Tk()
# top.geometry('50x50')
# top.title('shop')

# url = 'http://www.google.com'


    
# noti = ToastNotifier() 
# btn = Button(top, text= "Enter", command=notify)
# btn.pack()

# top.mainloop()